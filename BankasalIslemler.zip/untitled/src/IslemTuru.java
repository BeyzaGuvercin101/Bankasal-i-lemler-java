public class IslemTuru {
    private String isim;
    public IslemTuru(String isim) {
        this.isim = isim;
    }
    public String getIsim() {
        return isim;
    }
    @Override
    public String toString() {
        return isim;
    }
}



public class KrediDepartmani extends Departman {
    @Override
    protected boolean islemUygunMu(Islem islem) {
        return islem.getTur().getIsim().equals("Kredi Başvurusu");
    }
    @Override
    protected void islemIsle(Islem islem) {
        System.out.println("Kredi Departmanı işledi: " + islem.getDetaylar());
    }
}

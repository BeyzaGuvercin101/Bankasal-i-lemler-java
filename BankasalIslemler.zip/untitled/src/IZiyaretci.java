public interface IZiyaretci {
    void ziyaretEt(Islem islem);

}

import java.util.HashMap;
import java.util.Map;

public class IslemTuruFabrikasi {
    private static final Map<String, IslemTuru> turler = new HashMap<>();
    public static IslemTuru getIslemTuru(String isim) {
        turler.putIfAbsent(isim, new IslemTuru(isim));
        return turler.get(isim);
    }
}
class BankaSistemi{

    public static void main(String[] args) {
        Departman kD = new KrediDepartmani();
        Departman transferD = new TransferDepartmani();
        kD.setSonraki(transferD);

        Islem islem1 = new Islem("Kredi Basvurusu", "50000 TL kredi basvurusu");
        Islem islem2 = new Islem("Para Transferi", "1000 TL transfer");
        Islem islem3 = new Islem("Hesap Acma", "Yeni mevduat hesabi acma");

        kD.islemYap(islem1);
        kD.islemYap(islem2);
        kD.islemYap(islem3);

        IZiyaretci risk_Analizi = new RiskAnaliziZiyaretci();
        islem1.kabulEt(risk_Analizi);
        islem2.kabulEt(risk_Analizi);

    }

}
